# GameStore - Full Project (Static frontend + Node backend demo)

This bundle contains a **static frontend** (single-file `index.html`) and a **Node/Express backend** (mock-order flow + webhook example). It is ready for local testing and quick deploy to static hosting (Vercel/Netlify) and server hosting (Railway/Render).

## Structure
```
gamestore_project/
  frontend/index.html
  backend/
    server.js
    package.json
    .env.example
```

## Run locally
### Backend
```bash
cd backend
cp .env.example .env
# edit .env if you want to set DEMO_WEBHOOK_SECRET
npm install
npm run dev   # needs nodemon or use npm start
# default: http://localhost:4000
```

### Frontend
You can open `frontend/index.html` directly in a browser (it will fetch `/api/products` if the backend is hosted at the same origin). For local testing with the backend on port 4000, run a simple static server (Python):
```bash
# from project root
cd frontend
# serve at port 5173 for example
python3 -m http.server 5173
# then open http://localhost:5173 in your browser
# or use Live Server / VSCode or deploy to Vercel/Netlify
```

## Deploy guide (quick)
- Frontend: Deploy `frontend/index.html` as a static site to **Vercel** or **Netlify**. Both allow drag-and-drop or connect to GitHub repo.
- Backend: Deploy `backend` to **Railway** or **Render**. Set `DEMO_WEBHOOK_SECRET` in environment variables. For production, add real payment provider keys and secure file storage (S3) and implement signed URLs for downloads.

## Payment & downloads (notes)
- This demo uses a mock `POST /api/create-order` and an in-memory ORDERS object. For production:
  - Use Razorpay/Cashfree/Paytm SDK on the server to create orders and verify payments.
  - Implement `POST /api/webhook` to verify provider signatures and mark orders as paid.
  - Generate signed download URLs (AWS S3 pre-signed URLs or Cloud Storage signed URLs) tied to paid orders. Never serve files directly from a public bucket.
